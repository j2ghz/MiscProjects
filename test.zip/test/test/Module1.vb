﻿Module Module1

    Sub Main()
        Console.WriteLine("test")
        Console.ReadKey()

    End Sub

End Module
